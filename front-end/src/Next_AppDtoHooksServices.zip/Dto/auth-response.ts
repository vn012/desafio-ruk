export interface AuthResponse {
    token: string;
    message: string;
}

